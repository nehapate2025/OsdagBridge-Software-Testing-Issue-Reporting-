"""Footpath component package."""
