"""Pier checks stub."""
